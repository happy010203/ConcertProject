
package com.example.MyJBA.dao;
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
 
import com.example.MyJBA.entity.MyBook;

import jakarta.transaction.Transactional;
 
@Repository
public interface MyBookDao  extends JpaRepository<MyBook, Long> , JpaSpecificationExecutor<MyBook>{
 
	MyBook findByName(String name);
	
	List<MyBook> findByPriceGreaterThanEqual(int from);
	
	List<MyBook> findByPriceLessThanEqualAndNameLike(int price, String name);
	
	@Transactional
	@Modifying
	@Query(
			nativeQuery = true,
			value = """
					update mybook set publishing_House =?1 where price > ?2
					"""
			)
	int updateHouse(String houseName, int price);
	
	//三個" 是多行字串的意思
	@Query(
            nativeQuery = true,
            value = """  
                SELECT *
                FROM mybook
                WHERE name = ?1 OR publishing_House = ?2
            """
    )
    List<MyBook> findByTwoName(String name, String publishingHouse);
	
	
	@Query(
            nativeQuery = true,
            value = """  
                SELECT *
                FROM mybook
                where publishing_House = ?1
                limit ?2 , ?3
            """
    )
    List<MyBook> mybookPage(String house ,int pos, int pageSize);
	
	@Query(
            nativeQuery = true,
            value = """  
                SELECT count(*)
                FROM mybook
                where publishing_House = ?1
            """
    )
    long countMyPage(String house);
	
	
}