package com.example.MyJBA.action;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.example.MyJBA.entity.MyBook;

import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;

public class MyBookPage {
	
}
