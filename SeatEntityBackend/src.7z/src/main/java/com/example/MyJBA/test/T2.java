package com.example.MyJBA.test;

public class T2 extends Thread {
	
	public T2(String name) {
		super(name);	
		
	}
	
	public void run() {
		for(int i  = 0; i<10; i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("end run...");
	}
	
	public static void main(String[] args) {
		
		System.out.println("start...");
		T2 t = new T2("abc");
		System.out.println(t);
		t.start();
		System.out.println("end...");
	}
	
}
