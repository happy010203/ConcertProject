package com.example.MyJBA.test;

public class T4 {

	public static void main(String[] args) {
		//匿名類別，只能使用一次，若要多用，獨立出一個method
		System.out.println("start...");
		Thread t2 = new Thread(
				new Runnable() {
					public void run() {
						for(int i  = 0; i<10; i++) {
							System.out.println(i);
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						System.out.println("end run...");
					}//end run
				}//end Runnable 匿名類別
				);
		t2.start();
		System.out.println("end...");
	}

}
