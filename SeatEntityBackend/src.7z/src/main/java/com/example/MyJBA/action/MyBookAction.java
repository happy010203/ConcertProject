package com.example.MyJBA.action;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MyJBA.dao.MyBookDao;
import com.example.MyJBA.entity.MyBook;
import com.example.MyJBA.vo.MyBookVo;

import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;

@RestController
@RequestMapping("MyBook")
public class MyBookAction {
	
	@Autowired
	MyBookDao myBookDao;
	
	@GetMapping("mywhere")
	public Map mywhere() {
		Map rs = new HashMap();
		
		List<MyBook> list = findWithCondition("Spring Boot 4", "Spring出版社");
		List<MyBookVo> listVo = new ArrayList();
		for(MyBook book:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties(book, vo);//複製資源
			listVo.add(vo);
		}
		rs.put("success", true);
		rs.put("book", listVo);
		return rs;
	}
	
	public List<MyBook> findWithCondition(String name, String house) {
        Specification<MyBook> spec = (root, query, builder) -> {
          List<Predicate> predicates = new ArrayList<>();
          if (name != null && !"".equals(name.trim())) { //trim()針對表單資料需要去空白(只能去半形空白)
            Expression<String> nameExp = root.get("name").as(String.class);
            predicates.add(builder.equal(nameExp, name));
          }
          if (house != null) {
            Expression<String> publishingHouseExp = root.get("publishingHouse").as(String.class);
            predicates.add(builder.equal(publishingHouseExp, house));
          }
          query.where(builder.and(predicates.toArray(new Predicate[0])));
          return query.getRestriction();
        };
        return myBookDao.findAll(spec);
	}
	
	//儲存
	@GetMapping("insert")
	public Map insert() {
		System.out.println("insert.....");
		Map rs = new HashMap();
		MyBook mybook = new MyBook();	//MyBook物件化
		mybook.setName("Spring Boot 11");	//放入資料
		mybook.setPrice(1000);
		mybook.setPublicationDate(LocalDate.parse("2021-01-01"));
		mybook.setPublishingHouse("Spring出版社");
		myBookDao.save(mybook);
		rs.put("success", true);
		rs.put("mybook", mybook);
		return rs;
	}
	
	//查詢
	@GetMapping("queryOne")
	public Map queryOne() {
		System.out.println("queryOne......");
		Map rs = new HashMap();
		MyBook mybook = myBookDao.getReferenceById(1L);
		MyBookVo vo = new MyBookVo();
//		vo.setId(mybook.getId());
//		vo.setName(mybook.getName());
//		vo.setPrice(mybook.getPrice());
//		vo.setPublicationDate(mybook.getPublicationDate());
//		vo.setPublishingHouse(mybook.getPublishingHouse());
		BeanUtils.copyProperties(mybook, vo); //這一行等於上面5行
		rs.put("success", true);
		rs.put("mybook", vo);
		return rs;
	}
	
	@GetMapping("update")
	public Map update() {
		System.out.println("update......");
		Map rs = new HashMap();
		MyBook mybook = new MyBook();
		mybook.setId(1L);
		mybook.setName("Spring Boot 3");	//放入資料
		mybook.setPrice(150);
		mybook.setPublicationDate(LocalDate.parse("2021-01-01"));
		mybook.setPublishingHouse("Spring出版社");
		myBookDao.save(mybook);
		rs.put("success", true);
		rs.put("mybook", mybook);
		return rs;
	}
	
	@GetMapping("delete")
	public Map delete() {
		Map rs = new HashMap();
		myBookDao.deleteById(1L);
		rs.put("success", true);
		return rs;
	}
	
	//搜尋
	@GetMapping("queryBookName")
	public Map queryBookName() {
		Map rs = new HashMap();
		System.out.println("queryBookName......");
		MyBook mybook = 
				myBookDao.findByName("Spring Boot 6");
		MyBookVo vo = new MyBookVo();
		BeanUtils.copyProperties(mybook, vo);
		rs.put("success", true);
		rs.put("mybook", mybook);
		return rs;
	}
	
	@GetMapping("priceMore400")
	public Map priceMore400() {
		Map rs = new HashMap();
		System.out.println("priceMore400......");
		List<MyBook> list = myBookDao.findByPriceGreaterThanEqual(400);
		List<MyBookVo> listVo = new ArrayList<>();
		for(MyBook mybook:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties(mybook, vo);
			listVo.add(vo);
		}
		rs.put("success", true);
		rs.put("list", listVo);
		return rs;
	}
	
	@GetMapping("query2")
	public Map query2() {
		Map rs = new HashMap();
		System.out.println("queryBookName......");
		List<MyBook> list =
				myBookDao.findByPriceLessThanEqualAndNameLike(300, "%Spring Boot%");
		List<MyBookVo> listVo = new ArrayList<>();
		for(MyBook mybook:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties( mybook, vo);
			listVo.add(vo);
		}
		rs.put("success", true);
		rs.put("list", listVo);
		return rs;
	}
	
	@GetMapping("twoName")
	public Map twoName() {
		Map rs = new HashMap();
		System.out.println("twoName......");
		List<MyBook> list =
				myBookDao.findByTwoName("Spring Boot 4", "Java官方出版社");
		List<MyBookVo> listVo = new ArrayList<>();
		for(MyBook mybook:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties( mybook, vo);
			listVo.add(vo);
		}
		rs.put("success", true);
		rs.put("list", listVo);
		return rs;
	}
	
	@GetMapping("updateHouse")
	public Map updateHouse() {
		Map rs = new HashMap();
		System.out.println("updateHouse......");
		int x = myBookDao.updateHouse("java官方出版社", 800);
		rs.put("success", true);
		rs.put("x", x);
		return rs;
	}
	
	//第6筆開始(不包含6)，秀出2筆資料
	@GetMapping("mybookPage")
	public Map mybookPage() {
		Map rs = new HashMap();
		System.out.println("updateHouse......");
		List<MyBook> list =
				myBookDao.mybookPage("Spring官方出版社", 6, 2);//第6筆開始(不包含6)，秀出2筆資料
		List<MyBookVo> listVo = new ArrayList<>();
		for(MyBook mybook:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties( mybook, vo);
			listVo.add(vo);
		}
		long count = myBookDao.countMyPage("Spring官方出版社");
		rs.put("success", true);
		rs.put("list", listVo);
		rs.put("count", count);
		return rs;
	}
	
	@GetMapping("queryPage")
    public Map queryPage() {
        Map rs = new HashMap();
        Page<MyBook> list =
				myBookDao.findAll(
						PageRequest.of(3, 2) //從第0頁開始，3是第四頁，一頁2筆到第4頁是第幾筆?第7、第8
						);
        List<MyBookVo> listVo = new ArrayList<>();
		for(MyBook mybook:list) {
			MyBookVo vo = new MyBookVo();
			BeanUtils.copyProperties( mybook, vo);
			listVo.add(vo);
		}
		rs.put("list", listVo);
		rs.put("list", listVo);
		rs.put("count", list.getTotalElements());	//資料總筆數
		rs.put("allPage", list.getTotalPages());	//資料總頁數
		rs.put("thisPageCount", list.getNumberOfElements());	//本業有幾筆資料
        return rs;
	}
}
