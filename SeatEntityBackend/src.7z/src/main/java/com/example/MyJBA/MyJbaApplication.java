package com.example.MyJBA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyJbaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyJbaApplication.class, args);
	}

}
