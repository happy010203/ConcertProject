package com.example.MyJBA.test;

public class T6 {

	public static void main(String[] args) {
		System.out.println("start...");
		Thread t2 = new Thread(() -> System.out.println("end run...")); {
			
		};
		t2.start();
		System.out.println("end");
	}

}
