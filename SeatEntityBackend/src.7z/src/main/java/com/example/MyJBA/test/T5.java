package com.example.MyJBA.test;

public class T5 {

	public static void main(String[] args) {
		Thread t = new Thread() {public void run() {
			for(int i  = 0; i<10; i++) {
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("end run...");
		}//end run}; //大括號代表繼承Thread()類別

	};
	t.start();
	System.out.println("end...");
	}
}
