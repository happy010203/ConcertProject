package com.example.MyJBA.test;

public class T3 implements Runnable {

	@Override
	public void run() {
		for(int i  = 0; i<10; i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("end run...");
	}

	public static void main(String[] args) {
		System.out.println("start...");
		T3 t = new T3();
//		t.run(); //呼叫run()仍是單一執行續
		Thread t2 = new Thread(t);
		t2.start(); //用start()才會呼叫另一個執行緒
		System.out.println("end");

	}

}
